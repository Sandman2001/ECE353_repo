/**
 * @file hw01.c
 * @author your name (you@domain.com)
 * @brief
 * @version 0.1
 * @date 2023-09-16
 *
 * @copyright Copyright (c) 2023
 *
 */
#include "main.h"
#include "hw02.h"
#include "hw02-lcd-staff.h"
#include "hw02-images.h"

/*****************************************************************************/
/*  Global Variables                                                         */
/*****************************************************************************/
char HW02_DESCRIPTION[] = "ECE353: HW02 Geoffrey, Vincent";

/*****************************************************************************/
/*  Interrupt Handlers                                                       */
/*****************************************************************************/

/* Timer object and timer_cfg object */
cyhal_timer_t timer_obj;
cyhal_timer_cfg_t timer_cfg;

volatile button_state_t ALERT_SW1 = BUTTON_INACTIVE;
volatile button_state_t ALERT_SW2 = BUTTON_INACTIVE;
volatile joystick_position_t currJoy = JOYSTICK_POS_CENTER;

/**
 * @brief
 *  Function used as Timer Handler
 */
void Handler_HW02_Timer(void *handler_arg, cyhal_timer_event_t event)
{

    static bool SW1_Was_Pressed;
    static bool SW2_Was_Pressed;
    uint32_t reg_val = PORT_BUTTONS->IN;

    // If the switch is not currently being pressed
    if ((reg_val & SW1_MASK) != 0)
    {
        // If it was being pressed before
        if (SW1_Was_Pressed)
        {
            // SW has been released, set flags
            ALERT_SW1 = BUTTON_SW1_PRESSED;
            SW1_Was_Pressed = false;
        }
        else
        {
            // Otherwise SW not pressed now & not pressed before
            SW1_Was_Pressed = false;
        }
    }
    else
    {
        // SW is currently being pressed
        SW1_Was_Pressed = true;
    }

    // If the switch is not currently being pressed
    if ((reg_val & SW2_MASK) != 0)
    {
        // If it was being pressed before
        if (SW2_Was_Pressed)
        {
            // SW has been released, set flags
            ALERT_SW2 = BUTTON_SW2_PRESSED;

            SW2_Was_Pressed = false;
        }
        else
        {
            // SW not pressed now & not pressed before
            SW2_Was_Pressed = false;
        }
    }
    else
    {
        // SW is currently being pressed
        SW2_Was_Pressed = true;
    }

    currJoy = joystick_get_pos();
}

/*****************************************************************************/
/*  HW02 Functions                                                           */
/*****************************************************************************/

/**
 * @brief
 * Checks if space is occupied by a player
 * @param gameBoard the tic tac toe board
 * @param row the row being checked
 * @param col the column being checked
 */
bool is_space_occupied(char gameBoard[3][3], int row, int col)
{
    return (gameBoard[row][col] != NULL);
}

/**
 * @brief
 * Checks if there is a winner
 * @return -1 for 'O' win, 0 for no winner, 1 for 'X' win
 */
int check_for_winner(char gameBoard[3][3])
{
    // Checking rows
    for (int i = 0; i < 3; i++)
    {
        if (gameBoard[i][0] == 'O' && gameBoard[i][1] == 'O' && gameBoard[i][2] == 'O')
        {
            return -1;
        }
        if (gameBoard[i][0] == 'X' && gameBoard[i][1] == 'X' && gameBoard[i][2] == 'X')
        {
            return 1;
        }
    }

    // Checking collumns
    for (int j = 0; j < 3; j++)
    {

        if (gameBoard[0][j] == 'O' && gameBoard[1][j] == 'O' && gameBoard[2][j] == 'O')
        {
            return -1;
        }
        if (gameBoard[0][j] == 'X' && gameBoard[1][j] == 'X' && gameBoard[2][j] == 'X')
        {
            return 1;
        }
    }

    // Down Right diagonal
    if (gameBoard[0][0] == 'O' && gameBoard[1][1] == 'O' && gameBoard[2][2] == 'O')
    {
        return -1;
    }
    if (gameBoard[0][0] == 'X' && gameBoard[1][1] == 'X' && gameBoard[2][2] == 'X')
    {
        return 1;
    }

    // Down left diagonal
    if (gameBoard[2][0] == 'O' && gameBoard[1][1] == 'O' && gameBoard[0][2] == 'O')
    {
        return -1;
    }
    if (gameBoard[2][0] == 'X' && gameBoard[1][1] == 'X' && gameBoard[0][2] == 'X')
    {
        return 1;
    }

    // No Winner
    return 0;
}

/**
 * @brief
 * draws occupied space
 * @param gameBoard the tic tac toe board
 * @param i the row being drawn
 * @param j the column being drawn
 */
void draw_occupied_space(int i, int j, char gameBoard[3][3])
{
        if (gameBoard[i][j] == 'O')
                {
                  
                    /* Prints out correct square with claimed coloring for O */
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(LEFT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(LEFT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(LEFT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(CENTER_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(CENTER_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(CENTER_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(RIGHT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(RIGHT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(RIGHT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    }
                }
                else if (gameBoard[i][j] == 'X')
                {
                    /* Prints out correct square with claimed coloring for X */
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(LEFT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(LEFT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(LEFT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(LEFT_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(CENTER_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(CENTER_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(CENTER_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(CENTER_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(RIGHT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(RIGHT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(RIGHT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_CLAIMED);
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_CLAIMED, BG_COLOR_CLAIMED);
                            break;
                        }
                        break;
                    }
                }
}

/**
 * @brief
 * draws unoccupied space
 * @param gameBoard the tic tac toe board
 * @param i the row being drawn
 * @param j the column being drawn
 */
void draw_unoccupied_space(int i, int j, char currentTurn, char gameBoard[3][3])
{
        if (currentTurn == 'O')
                {
                    /* Print correct square with unclaimed colors for O */
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(LEFT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(LEFT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(LEFT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(CENTER_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(CENTER_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(CENTER_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(RIGHT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(RIGHT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(RIGHT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    }
                }
                else if (currentTurn == 'X')
                {
                    /* Print out correct square with unclaimed coloring for X */
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(LEFT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(LEFT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(LEFT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(LEFT_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(CENTER_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(CENTER_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(CENTER_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(CENTER_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_rectangle_centered(RIGHT_COL, UPPER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 1:
                            lcd_draw_rectangle_centered(RIGHT_COL, CENTER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        case 2:
                            lcd_draw_rectangle_centered(RIGHT_COL, LOWER_ROW, SQUARE_SIZE, SQUARE_SIZE, BG_COLOR_UNCLAIMED);
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_UNCLAIMED, BG_COLOR_UNCLAIMED);
                            break;
                        }
                        break;
                    }
                }
}

/**
 * @brief
 * draws space of board 
 * @param gameBoard the tic tac toe board
 * @param i the row being drawn
 * @param j the column being drawn
 */
void draw_space(int i, int j, char gameBoard[3][3])
{
                    /* Print out square with default coloring for O */
                if (gameBoard[i][j] == 'O')
                {
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(LEFT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 1:
                            lcd_draw_image(LEFT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 2:
                            lcd_draw_image(LEFT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(CENTER_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 1:
                            lcd_draw_image(CENTER_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 2:
                            lcd_draw_image(CENTER_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 1:
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        case 2:
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_O, FG_COLOR_O, BG_COLOR_O);
                            break;
                        }
                        break;
                    }
                }
                else if (gameBoard[i][j] == 'X')
                {
                    /* Print out default coloring for X */
                    switch (i)
                    {
                    case 0:
                        // Left Column Selection
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(LEFT_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 1:
                            lcd_draw_image(LEFT_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 2:
                            lcd_draw_image(LEFT_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        }
                        break;
                    // Center Column Selection
                    case 1:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(CENTER_COL, UPPER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 1:
                            lcd_draw_image(CENTER_COL, CENTER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 2:
                            lcd_draw_image(CENTER_COL, LOWER_ROW, X_WIDTH, X_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        }
                        break;
                    // Right Column Selection
                    case 2:
                        switch (j)
                        {
                        case 0:
                            lcd_draw_image(RIGHT_COL, UPPER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 1:
                            lcd_draw_image(RIGHT_COL, CENTER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        case 2:
                            lcd_draw_image(RIGHT_COL, LOWER_ROW, O_WIDTH, O_HEIGHT, Bitmaps_X, FG_COLOR_X, BG_COLOR_X);
                            break;
                        }
                        break;
                    }
                }
}

/**
 * @brief
 * Calls all needed draw methods for the current state of the board
 * @param gameBoard the board that will printed out
 * @param x row coordinate of active square
 * @param y collumn coordinate of active square
 * @param currentTurn the current player's character 'X' or 'O'
 */
void draw_current_board(char gameBoard[3][3], int x, int y, char currentTurn)
{
    
    // Draws the board
    tic_tac_toe_draw_grid();
    
    // Traverses board spaces
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            // if the square to print out is the current square the player is on
            if (i == x && j == y)
            {
                /* Check if space is occupied */
                if (is_space_occupied(gameBoard, x, y))
                {
                    // Draws space with occupied colors
                    draw_occupied_space(i,j, gameBoard);
                } else {
                    // Draws space with unoccupied colors
                    draw_unoccupied_space(i, j, currentTurn, gameBoard);
                }
            }
            else
            {
                // Draws space with default coloring
                draw_space(i, j, gameBoard);
            }
        }
    }
}

/**
 * @brief
 * initializes game with starting player and determines player characters
 * @param currTurn pointer to variable that stores the current players turn
 * @param ourChar pointer to variable the stores our character
 * @param x row coordinate of active square
 * @param y collumn coordinate of active square
 * @param gameBoard the tic tac toe board
 */
void initial_game_setup(char *currTurn, char *ourChar, int x, int y, char gameBoard[3][3]){
    
    bool exitCondition = false;
    char remote_rx_message[2];
    char P1_SELECT = (char)0x5A;
    char X_SELECT = (char)0x58;
    char O_SELECT = (char)0x4F;
    char ACK_cmd = (char)0xF0;


    /* Clear out the array holding the message */
    memset(remote_rx_message, 0, 2);

    cyhal_uart_putc(&cy_retarget_io_uart_obj, '\r');

    lcd_select_player1();

    while(ALERT_SW2 != BUTTON_SW2_PRESSED && !exitCondition) 
    {
        if (ALERT_UART_RX)
        {
            /* Set the alert back to false*/
            ALERT_UART_RX = false;

            /* Initialize the array to all 0*/
            memset(remote_rx_message, 0, 2);

            if (remote_uart_rx_data_async(remote_rx_message, 2))
            {
                if (remote_rx_message[0] == P1_SELECT)
                {
                    exitCondition = true;
                }
            }
        }
    }
        /* Check to see if the user has entered a string into the console*/
        if (ALERT_SW2 == BUTTON_SW2_PRESSED && !exitCondition)
        {
            // reset alert
            ALERT_SW2 = BUTTON_SW2_RELEASED;

            /* Send the String to the remote board */
            remote_uart_tx_char_async(P1_SELECT);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');

            exitCondition = false;

            while(!exitCondition)
            {
            
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                    memset(remote_rx_message, 0, 2);


                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        if (remote_rx_message[0] == ACK_cmd)
                        {
                        exitCondition = true;
                        }
                    }
                }  
            }

            *ourChar = 'O';
            lcd_clear_screen(LCD_COLOR_BLACK);
            draw_current_board(gameBoard, x, y, *ourChar);

            while (ALERT_SW2 != BUTTON_SW2_PRESSED)
            {
                if (ALERT_SW1 == BUTTON_SW1_PRESSED)
                {
                    ALERT_SW1 = BUTTON_SW1_RELEASED;
                    if (*ourChar == 'O')
                    {
                        *ourChar = 'X';
                    } else if (*ourChar == 'X')
                    {
                        *ourChar = 'O';
                    }
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, *ourChar);
                }
            }

            ALERT_SW2 = BUTTON_SW2_RELEASED;
            *currTurn = *ourChar;

            if (*ourChar == 'X'){
                /* Send the String to the remote board */
                remote_uart_tx_char_async(X_SELECT);
                /* Need to send a \r or \n to indicate the end of a string*/
                remote_uart_tx_char_async('\n');
            } else if (*ourChar == 'O'){
                /* Send the String to the remote board */
                remote_uart_tx_char_async(O_SELECT);
                /* Need to send a \r or \n to indicate the end of a string*/
                remote_uart_tx_char_async('\n');
            }

            exitCondition = false;

            while(!exitCondition)
            {
            
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                     memset(remote_rx_message, 0, 2);

                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        if (remote_rx_message[0 == ACK_cmd])
                        {
                        exitCondition = true;
                        }
                    }
                }  
            }

        } else {
            
            /* Send the String to the remote board */
            remote_uart_tx_char_async(ACK_cmd);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');

            lcd_clear_screen(LCD_COLOR_BLACK);
            tic_tac_toe_draw_grid();
            lcd_wait_for_other_player();

            exitCondition = false;

            while(!exitCondition)
            {
            
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                     memset(remote_rx_message, 0, 2);

                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        if (remote_rx_message[0] == X_SELECT || remote_rx_message[0] == O_SELECT)
                        {
                            exitCondition = true;
                        }
                    }
                }  
            }
            if (remote_rx_message[0] == X_SELECT)
            {
                *ourChar = 'O';
                *currTurn = 'X';
            } else if (remote_rx_message[0] == O_SELECT)
            {
                *ourChar = 'X';
                *currTurn = 'O';
            }

            /* Send the String to the remote board */
            remote_uart_tx_char_async(ACK_cmd);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');

        }

}

/**
 * @brief
 * Sends move to other board and waits for ACK cmd
 * @param x the row of move being played
 * @param y the column of move being played
 */
void send_move(int x, int y)
{
    // char casted hex value 0xXY
    char toSend = (char)((x << 4) | y);

    /* Send the String to the remote board */
    remote_uart_tx_char_async(toSend);
    /* Need to send a \r or \n to indicate the end of a string*/
    remote_uart_tx_char_async('\n');

    char remote_rx_message[2];
    char ACK_cmd = (char)0xF0;
    bool exitCondition = false;

            while(!exitCondition)
            {
                // If we recieve a message
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                    memset(remote_rx_message, 0, 2);


                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        // if we recieved the ACK cmd
                        if (remote_rx_message[0] == ACK_cmd)
                        {
                        exitCondition = true;
                        }
                    }
                }  
            }


}

/**
 * @brief
 * Waits for other players move and sets x, y coordinates to other players move 
 * @param x pointer to variable containing row coordinate of current selected square
 * @param y pointer to variable containing collumn coordinate of current selected square
 */
void wait_for_other_player(int *x, int *y)
{
    char remote_rx_message[2];
    char ACK_cmd = (char)0xF0;
    bool exitCondition = false;

            while(!exitCondition)
            {
            
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                    memset(remote_rx_message, 0, 2);


                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        int x_coordinate = (int)(remote_rx_message[0] >> 4);
                        int y_coordinate = (int)(remote_rx_message[0] & 0xF);
                        if (x_coordinate > 2 || x_coordinate < 0 || y_coordinate > 2 || y_coordinate < 0){
                            continue;
                        }
                        
                        *x = x_coordinate;
                        *y = y_coordinate;

                        exitCondition = true;
                        
                    }
                }  
            }

            /* Send the String to the remote board */
            remote_uart_tx_char_async(ACK_cmd);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');


}

/**
 * @brief
 * Waits until a player initializes new game
 * @param currTurn pointer to variable that stores whos turn it is
 * @param ourChar pointer to variable that stores our character
 * @return true if new game was started, false otherwise
 */
bool start_new_game(char *currTurn, char *ourChar)
{
    bool exitCondition = false;
    char remote_rx_message[2];
    char P1_SELECT = (char)0x5A;
    char ACK_cmd = (char)0xF0;


    /* Wait for button press or P1_SELECT cmd */
    while(ALERT_SW2 != BUTTON_SW2_PRESSED && !exitCondition) 
    {
        if (ALERT_UART_RX)
        {
            /* Set the alert back to false*/
            ALERT_UART_RX = false;

            /* Initialize the array to all 0*/
            memset(remote_rx_message, 0, 2);

            /* check if the char recieved is the player 1 select*/
            if (remote_uart_rx_data_async(remote_rx_message, 2))
            {
                if (remote_rx_message[0] == P1_SELECT)
                {
                    exitCondition = true;
                }
            }
        }
    }

        /* Check if we hit the button */
        if (ALERT_SW2 == BUTTON_SW2_PRESSED && !exitCondition)
        {
            // reset alert
            ALERT_SW2 = BUTTON_SW2_RELEASED;

            /* Send the String to the remote board */
            remote_uart_tx_char_async(P1_SELECT);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');

            exitCondition = false;

            while(!exitCondition)
            {
            
                if (ALERT_UART_RX)
                {
                    /* Set the alert back to false*/
                    ALERT_UART_RX = false;

                    /* Initialize the array to all 0*/
                    memset(remote_rx_message, 0, 2);

                    /* confirm string recieved is the ACK cmd */
                    if (remote_uart_rx_data_async(remote_rx_message, 2))
                    {
                        if (remote_rx_message[0] == ACK_cmd)
                        {
                        exitCondition = true;
                        }
                    }
                }  
            }
            // We go First!
            *currTurn = *ourChar;
            return true;
        } else // we recieved P1_SELECT
        {
            /* Send the String to the remote board */
            remote_uart_tx_char_async(ACK_cmd);
            /* Need to send a \r or \n to indicate the end of a string*/
            remote_uart_tx_char_async('\n');

            lcd_clear_screen(LCD_COLOR_BLACK);
            tic_tac_toe_draw_grid();
            lcd_wait_for_other_player();

            // We go second!
            if (*ourChar == 'X')
            {
                *currTurn = 'O';
            } else if (*ourChar == 'O')
            {
                *currTurn = 'X';
            }
            return true;

        }
}

/**
 * @brief
 * Initializes the PSoC6 Peripherals used for HW01
 */
void hw02_peripheral_init(void)
{
    /* Initialize the pushbuttons */
    push_buttons_init();

    /* Initialize the LCD */
    ece353_enable_lcd();

    /* Initialize the joystick*/
    joystick_init();

    /* Initialize the remote UART */
    remote_uart_init();

    // Enable interrupts and circular buffers from remote board.
    remote_uart_enable_interrupts();

    /* Initialize Timer to generate interrupts every 100mS*/
    timer_init(&timer_obj, &timer_cfg, TICKS_MS_100, Handler_HW02_Timer);
}

/**
 * @brief
 * Implements the main application for HW02
 */
void hw02_main_app(void)
{
    int x = 1; // keeps track of x coordinate of current player, 1 corisponds to center square
    int y = 1; // keeps track of y coordinate of current player, 1 corisponds to center square
    char gameBoard[3][3]; // 2D array of chars to keep track of board

    /* Initialize array to NULL*/
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            gameBoard[i][j] = NULL;
        }
    }

    int totalMoves = 0; // keeps track of # of moves, max # of moves is 9
    bool gameRunning = true; // true if game is in progress, false otherwise
    // winner will be 0 for tie, -1 for 'O', 1 for 'X'
    int winner = 0; // used for comparison to determine winner
    char currTurn; // O starts game on launch, switches every game 
    char ourChar; // gets set in initial ACK
    joystick_position_t prevJoy = JOYSTICK_POS_CENTER; // Previous position of the joystick

    // handshake with other board to start game, sets currTurn & ourChar
    initial_game_setup(&currTurn, &ourChar, x, y, gameBoard);

    // Draw current state of board
    if (currTurn == ourChar)
    {
        draw_current_board(gameBoard, x, y, currTurn);
                    
    } else 
    {
        tic_tac_toe_draw_grid();
        lcd_wait_for_other_player();
    }


    while (1)
    {

        if (gameRunning)
        {

            // Checking for any win conditions
            winner = check_for_winner(gameBoard);

            // if the game has reached the max # of moves or a winner has been found
            if (totalMoves == 9 || winner != 0)
            {
                // stop game and display results
                gameRunning = !gameRunning;
                continue;
            }

            if (currTurn == ourChar){

            // checks for square movement, must return to center before player coordinates can change
            if (prevJoy == JOYSTICK_POS_CENTER)
            {   
                /* Check for current joystick position and update player position accordingly */
                if (currJoy == JOYSTICK_POS_UP)
                {

                    if (y == 0)
                    {
                        y = 2;
                    }
                    else
                    {
                        y--;
                    }
                    /* re-draw new board */
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, currTurn);
                }
                else if (currJoy == JOYSTICK_POS_DOWN)
                {
                    if (y == 2)
                    {
                        y = 0;
                    }
                    else
                    {
                        y++;
                    }
                    /* re-draw new board */
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, currTurn);
                }
                else if (currJoy == JOYSTICK_POS_LEFT)
                {
                    if (x == 0)
                    {
                        x = 2;
                    }
                    else
                    {
                        x--;
                    }
                    /* re-draw new board */
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, currTurn);
                }
                else if (currJoy == JOYSTICK_POS_RIGHT)
                {
                    if (x == 2)
                    {
                        x = 0;
                    }
                    else
                    {
                        x++;
                    }
                    /* re-draw new board */
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, currTurn);
                }

                /* update previous position for use in next iteration */
                prevJoy = currJoy;
            }
            else
            {
                /* Player has not moved */
                prevJoy = currJoy;
            }

            /* add move to game board */
            if (ALERT_SW1 == BUTTON_SW1_PRESSED)
            {
                // if the game board is empty
                if (gameBoard[x][y] == NULL)
                {

                    /* Add move to array and switch player */
                    if (currTurn == 'O')
                    {
                        gameBoard[x][y] = currTurn;
                        currTurn = 'X';
                    }
                    else
                    {
                        gameBoard[x][y] = currTurn;
                        currTurn = 'O';
                    }
                    /* Send move to other player & update game */
                    send_move(x, y);
                    totalMoves++;
                    lcd_clear_screen(LCD_COLOR_BLACK);
                    draw_current_board(gameBoard, x, y, currTurn);


                }
                // remove status flag
                ALERT_SW1 = BUTTON_SW1_RELEASED;
            }

            // removes any flags
            ALERT_SW2 = BUTTON_SW2_RELEASED;

            } else {
                lcd_wait_for_other_player();               
                wait_for_other_player(&x, &y);

                gameBoard[x][y] = currTurn;

                if (currTurn == 'O')
                {
                    currTurn = 'X';
                } else if (currTurn == 'X')
                {
                    currTurn = 'O';
                }
                totalMoves++;
                lcd_clear_screen(LCD_COLOR_BLACK);
                draw_current_board(gameBoard, x, y, currTurn);
            }
        }
        else
        {
            /* Print Game Results */
            switch (winner)
            {
            case 0:
                lcd_clear_screen(LCD_COLOR_BLACK);
                draw_current_board(gameBoard, x, y, currTurn);
                lcd_tie();
                break;

            case -1:
                lcd_clear_screen(LCD_COLOR_BLACK);
                draw_current_board(gameBoard, x, y, currTurn);
                lcd_O_wins();
                break;

            case 1:
                lcd_clear_screen(LCD_COLOR_BLACK);
                draw_current_board(gameBoard, x, y, currTurn);
                lcd_X_wins();
                break;
            }

            if (start_new_game(&currTurn, &ourChar))
            {
                // Resets gameBoard and other values for new round
                totalMoves = 0;
                x = 1;
                y = 1;

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        gameBoard[i][j] = NULL;
                    }
                }

                gameRunning = !gameRunning;
                lcd_clear_screen(LCD_COLOR_BLACK);
                if (currTurn == ourChar)
                {
                    draw_current_board(gameBoard, x, y, currTurn);
                } else 
                {
                    tic_tac_toe_draw_grid();
                    lcd_wait_for_other_player();
                }
            }
        }
    }
}